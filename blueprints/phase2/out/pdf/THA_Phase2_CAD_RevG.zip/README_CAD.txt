TROJAN HORSE ARENA - CAD FILES - Phase 2 Schematic Set Rev G (index = P2-G-001 Rev F; D-091 solar CUT, D-092, D-093)
Hazel Green Regional Athletic Complex, Madison County, Alabama (site TBD). Drawn by KEYSTONE (AI) for Shane Brazelton
(256-508-4608, brazeltonshane@gmail.com). Built 2026-10-11 (CT).

PRELIMINARY - CONCEPTUAL DESIGN - NOT FOR CONSTRUCTION. Schematic only. Not a code review; dimensions, heights, column spacing and
materials marked ASSUMED on the sheets are assumptions. A licensed architect / engineer must design, check and seal the work.

UNITS
  plans_feet/*_MODEL_ft.dxf : REAL UNITS, FEET (1 drawing unit = 1 ft; $INSUNITS = 2). Model space, origin 0,0 = the plan grid origin
                              (Phase 2: SW corner of the building grid, x east, y north; Phase 1: room SW inside corner).
                              Plan geometry only: title block, notes and other views on the sheet were left out. Text heights scale with it.
  sheets_inches/*.dxf       : each sheet as drawn, 1 unit = 1 inch on the 11 x 17 sheet (scaled drawings: read the scale on the sheet,
                              e.g. 1/40 in per ft = 1" = 40'). Use these to print / match the PDF.
  3d/*.obj + .mtl           : massing model, units FEET, Z up (A-901). Massing only, not a building model.

FILES
Sheets (inches):
  P2-G-001_RevF.dxf
  P2-G-002_RevG.dxf
  P2-G-003_RevN.dxf
  P2-C-101_RevH.dxf
  P2-A-101_RevN.dxf
  P2-A-102_RevI.dxf
  P2-A-103_RevE.dxf
  P2-A-111_RevF.dxf
  P2-A-201_RevN.dxf
  P2-A-301_RevF.dxf
  P2-A-302_RevC.dxf
  P2-A-401_RevE.dxf
  P2-A-901_RevI.dxf
Plans (feet):
  P2-A-101_RevN_MODEL_ft.dxf
  P2-A-102_RevI_MODEL_ft.dxf
  P2-A-111_RevF_MODEL_ft.dxf
3D model:
  P2-A-901_RevI_massing.obj
  P2-A-901_RevI_massing.mtl
Note: -

LAYERS (AIA-style names used in these files)
  A-ANNEX, A-ANNO-DIMS, A-ANNO-GHOST, A-ANNO-TEXT, A-ANNO-VIEW, A-AREA-OPEN, A-AREA-ZONE, A-CLER-ADA, A-COLS, A-DOOR, A-ELEV-DATM, A-ELEV-DOOR, A-ELEV-FACD, A-ELEV-FILL, A-ELEV-HIDN, A-ELEV-IDEN, A-ELEV-OTLN, A-ELEV-SIGN, A-EQPM-MATS, A-EXIT, A-EXIT-DISCH, A-EXIT-TRAVEL, A-FLOR-CRT, A-FLOR-STRS, A-FURN, A-GUARD, A-HATCH, A-LOOP, A-MASS, A-OPEN, A-PORTAL, A-ROOM, A-SEAT-TELE, A-SECT-CUTL, A-SECT-DATM, A-SECT-FILL, A-SECT-GUAR, A-SECT-HIDN, A-SECT-IDEN, A-SITE-CUTL, A-SITE-FILL, A-SITE-IDEN, A-SITE-SLIN, A-STAIR, A-TIER, A-WALL, A-WALL-EXT, A-WALL-PRTN, C-SITE, C-SITE-DIAG, G-ANNO-TABL, G-ANNO-TTLB, LS-CPTH, P-FIXT

OPENING THE FILES
  AutoCAD: OPEN the DXF directly (units already set). For the feet plans, INSERT / XREF with units = feet.
  Revit: Insert > Link CAD, Import units = Feet (plans_feet) and Positioning = Origin to Origin. Link, don't import, so updates reload.
  SketchUp: File > Import > AutoCAD (*.dxf), Options > Units = Feet. The OBJ also imports (File > Import > OBJ, units feet) in
  SketchUp 2021+ / Revit via a converter / Blender / Rhino.
The PDF set is the record; if a DXF and the PDF differ, the PDF governs.
