TROJAN HORSE ARENA - CAD FILES - Phase 1 Metal Building Proposal Set Rev B (D-095; P1-G-101, P1-A-201, P1-A-301, P1-A-901 Rev B)
Hazel Green Regional Athletic Complex, Madison County, Alabama (site TBD). Drawn by KEYSTONE (AI) for Shane Brazelton
(256-508-4608, brazeltonshane@gmail.com). Built 2026-10-11 (CT).

PRELIMINARY - CONCEPTUAL DESIGN - NOT FOR CONSTRUCTION. Schematic only. Not a code review; dimensions, heights, column spacing and
materials marked ASSUMED on the sheets are assumptions. A licensed architect / engineer must design, check and seal the work.

UNITS
  plans_feet/*_MODEL_ft.dxf : REAL UNITS, FEET (1 drawing unit = 1 ft; $INSUNITS = 2). Model space, origin 0,0 = the plan grid origin
                              (Phase 2: SW corner of the building grid, x east, y north; Phase 1: room SW inside corner).
                              Plan geometry only: title block, notes and other views on the sheet were left out. Text heights scale with it.
  sheets_inches/*.dxf       : each sheet as drawn, 1 unit = 1 inch on the 11 x 17 sheet (scaled drawings: read the scale on the sheet,
                              e.g. 1/40 in per ft = 1" = 40'). Use these to print / match the PDF.
  3d/*.obj + .mtl           : massing model, units FEET, Z up (A-901). Massing only, not a building model.

FILES
Sheets (inches):
  P1-G-101_RevB.dxf
  P1-A-201_RevB.dxf
  P1-A-301_RevB.dxf
  P1-A-901_RevB.dxf
Plans (feet):
  P1-A-201_RevB_MODEL_ft.dxf
3D model:
  (none for this phase)
Note: Metal building sizes are ASSUMED (params/phase1_metal_bldg_rev_b.yaml, D-095); frame by Summertown Metals' engineer.

LAYERS (AIA-style names used in these files)
  A-ANNO-DIMS, A-ANNO-EXIT, A-ANNO-TEXT, A-DOOR, A-ELEV-DATM, A-ELEV-DOOR, A-ELEV-GLAZ, A-ELEV-GRND, A-ELEV-ROOF, A-ELEV-SKIN, A-FLOR-MATS, A-FLOR-PADS, A-FLOR-PATT, A-FURN, A-MASS-CANO, A-MASS-DOOR, A-MASS-GLAZ, A-MASS-GRND, A-MASS-ROOF, A-MASS-WALL, A-SECT-DATM, A-SECT-GRND, A-SECT-MATS, A-SECT-PADS, A-SECT-ROOF, A-WALL, E-LITE, G-ANNO-TTLB, P-FIXT, S-COLS, S-FRAM, S-GRID

OPENING THE FILES
  AutoCAD: OPEN the DXF directly (units already set). For the feet plans, INSERT / XREF with units = feet.
  Revit: Insert > Link CAD, Import units = Feet (plans_feet) and Positioning = Origin to Origin. Link, don't import, so updates reload.
  SketchUp: File > Import > AutoCAD (*.dxf), Options > Units = Feet. The OBJ also imports (File > Import > OBJ, units feet) in
  SketchUp 2021+ / Revit via a converter / Blender / Rhino.
The PDF set is the record; if a DXF and the PDF differ, the PDF governs.
