TROJAN HORSE ARENA - CAD FILES - Phase 1 Set Rev A (P1-G-001 Rev E, P1-A-101 Rev C, P1-P-001 Rev A, P1-G-002 Rev B)
Hazel Green Regional Athletic Complex, Madison County, Alabama (site TBD). Drawn by KEYSTONE (AI) for Shane Brazelton
(256-508-4608, brazeltonshane@gmail.com). Built 2026-10-11 (CT).

PRELIMINARY - CONCEPTUAL DESIGN - NOT FOR CONSTRUCTION. Schematic only. Not a code review; dimensions, heights, column spacing and
materials marked ASSUMED on the sheets are assumptions. A licensed architect / engineer must design, check and seal the work.

UNITS
  plans_feet/*_MODEL_ft.dxf : REAL UNITS, FEET (1 drawing unit = 1 ft; $INSUNITS = 2). Model space, origin 0,0 = the plan grid origin
                              (Phase 2: SW corner of the building grid, x east, y north; Phase 1: room SW inside corner).
                              Plan geometry only: title block, notes and other views on the sheet were left out. Text heights scale with it.
  sheets_inches/*.dxf       : each sheet as drawn, 1 unit = 1 inch on the 11 x 17 sheet (scaled drawings: read the scale on the sheet,
                              e.g. 1/40 in per ft = 1" = 40'). Use these to print / match the PDF.
  3d/*.obj + .mtl           : massing model, units FEET, Z up (A-901). Massing only, not a building model.

FILES
Sheets (inches):
  P1-G-001_RevE_principal.dxf
  P1-A-101_RevC.dxf
  P1-P-001_RevA.dxf
Plans (feet):
  P1-A-101_RevC_MODEL_ft.dxf
3D model:
  (none for this phase)
Note: P1-G-002 Rev B (cost sheet) is PDF only: a table, no drawing geometry; no DXF is generated for it.

LAYERS (AIA-style names used in these files)
  A-ANNO-DIMS, A-ANNO-TEXT, A-DOOR-IDEN, A-FLOR-EXST, A-WALL, A-WALL-NMSR, G-ANNO-TTLB

OPENING THE FILES
  AutoCAD: OPEN the DXF directly (units already set). For the feet plans, INSERT / XREF with units = feet.
  Revit: Insert > Link CAD, Import units = Feet (plans_feet) and Positioning = Origin to Origin. Link, don't import, so updates reload.
  SketchUp: File > Import > AutoCAD (*.dxf), Options > Units = Feet. The OBJ also imports (File > Import > OBJ, units feet) in
  SketchUp 2021+ / Revit via a converter / Blender / Rhino.
The PDF set is the record; if a DXF and the PDF differ, the PDF governs.
